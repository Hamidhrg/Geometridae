library(phyloch)
library(TreePar)
library(dendextend)
library(phylotate)

### Extract rates from the Branch-specific result!
tree_rate<-read_annotated("Geo_BDS_rates_MAP.tree")
names(tree_rate)
length(tree_rate$node.distance.comment)
tail(tree_rate$node.comment)

### Create the list of Tips 
for_tip_index_extract<-unlist(strsplit(tree_rate$node.comment,split=","))
pre_tip_revBayes<-unlist(strsplit(for_tip_index_extract[grep("index=", for_tip_index_extract)],split="="))
tip_revBayes<-pre_tip_revBayes[seq(2,length(pre_tip_revBayes),2)]
tip_revBayes<-tip_revBayes[1:Ntip(tree_rate)]

### Extract lambda, mu and net diversification rates 
rate_extracted<-unlist(strsplit(tree_rate$node.distance.comment,split=","))
lamb<-unlist(strsplit(rate_extracted[grep("branch_lambda=", rate_extracted)],split="="))
lamb<-as.numeric(lamb[seq(2,length(lamb),2)])

mu<-unlist(strsplit(rate_extracted[grep("branch_mu=", rate_extracted)],split="="))
mu<-as.numeric(mu[seq(2,length(mu),2)])

netdiv<-unlist(strsplit(rate_extracted[grep("branch_net_div=", rate_extracted)],split="="))
netdiv <-as.numeric(netdiv[seq(2,length(netdiv),2)])


### Working on the biogeographical results! Node correspondance.
### Create a table for the node correspondence between the node numbers as RevBayes create it and as R read a tree.
### First, obtaining node numbers as in RevBayes:
ttree<-read_annotated("Geo_index.mcc.tre")
names(ttree)
ttree$node.comment

tab <- unlist(strsplit(ttree$node.comment, "="))
head(tab)

tab2<-tab[seq(2,length(tab),2)]

### Then place it in front of the numbers as in R:
mcc_tree<-read.nexus("Geo_index.mcc.tre")

node_correspond<-cbind(seq(Ntip(mcc_tree)+1,Ntip(mcc_tree)+Nnode(mcc_tree),1), tab2[seq(Ntip(mcc_tree)+1,Ntip(mcc_tree)+Nnode(mcc_tree),1)])

###Hamid# why?
tree<-mcc_tree

###Hamid# I dont understand getx function!

node_ages<-getx(mcc_tree)
node_ages<-node_ages[sort(names(node_ages))]

### Summary table
### R node numbers
summary_table<-seq(1, Ntip(mcc_tree)+Nnode(mcc_tree),1)

### RevBayes node numbers
summary_table<-cbind(node_R=summary_table,node_revBayes=c(tip_revBayes, node_correspond[,2]))

### Upper R node number
summary_table<-cbind(summary_table, upper_node_R=NA)
for(i in 1:nrow(summary_table))
{
	if(summary_table[i,1] == "1193"){summary_table[i,3]<-"1193"}
	else{summary_table[i,3]<-mcc_tree$edge[which(mcc_tree$edge[,2]== summary_table[i,1]),1]}
}


### R node age
summary_table<-cbind(summary_table,node_age=c(rep(0,Ntip(mcc_tree)),node_ages))

### R upper node age
summary_table<-cbind(summary_table, upper_node_age=NA)
for(i in 1:nrow(summary_table))
{
	summary_table[i,5]<-node_ages[which(names(node_ages) == summary_table[i,3])]
}



### R node biogeo state
mcmc_log<-read.table("Geo_.states.log",header=TRUE)
head(mcmc_log)

index_list<-read.table("Geo_.state_labels.txt",header=TRUE)
head(index_list)

tip_index<-c()

prob_mtx<-c()
max_prob_mtx<-c()
node_number_list<-c()

for(i in 2:ncol(mcmc_log))
{
	b<-strsplit(colnames(mcmc_log)[i], split = "_")[[1]]
	if(as.numeric(b[2])<=Ntip(tree))
	{
		if(b[1]=="end")
		{
			tip_index<-c(tip_index, names(table(mcmc_log[,i]))[1])
		}
	}
	else
	{
		if(b[1]=="end")
		{
			max_prob_mtx<-c(max_prob_mtx,names(table(mcmc_log[,i]))[which(table(mcmc_log[,i]) == max(table(mcmc_log[,i])))])	
			node_number_list<-c(node_number_list, b[2])		
			index_list_weighted<-index_list[names(table(mcmc_log[,i])),]
			for(j in 1:length(table(mcmc_log[,i])))
			{
				index_list_weighted[j,]<-index_list_weighted[j,] * table(mcmc_log[,i])[j]
			}
			prob_mtx<-rbind(prob_mtx,apply(index_list_weighted,2,sum)/sum(index_list_weighted))
		}
	}
print(i/ncol(mcmc_log))
}

index_list
head(index_list,20)

### Combined list of indexes (tip + nodes) following revBayes node numbers
max_prob_tipNode_index<-c(tip_index, max_prob_mtx)

index_list<-index_list[-1,]

for(i in 1:length(max_prob_tipNode_index))
{
	max_prob_tipNode_index[i] <- paste(colnames(index_list)[which(index_list[max_prob_tipNode_index[i],]==1)],collapse="")
}

tail(max_prob_tipNode_index)

names(max_prob_tipNode_index)<-1:(Ntip(mcc_tree)+Nnode(mcc_tree))

### Add the node biogeo state to the summary table
summary_table<-cbind(summary_table, node_R_state=NA)
for(i in 1:nrow(summary_table))
{
	summary_table[i,6]<-max_prob_tipNode_index[summary_table[i,2]]
}

### R upper node biogeo state
summary_table<-cbind(summary_table, upper_node_R_state=NA)
for(i in 1:nrow(summary_table))
{
	summary_table[i,7]<-summary_table[summary_table[,1]==summary_table[i,3],6]
}

head(summary_table,50)

### Identify nodes with shift 
summary_table<-cbind(summary_table, new_biogeo=NA)
for(i in 1:nrow(summary_table))
{
	disp<-setdiff(unlist(strsplit(summary_table[i,6],split="")),unlist(strsplit(summary_table[i,7],split="")))
	if(length(disp) != 0)
	{
		summary_table[i,8]<-paste(disp,collapse="")
	}
}

#- add lambda, mu and net div rate



#---- Create the event table: contains all nodes that have a biogeo shift

event_table<-c()
##Hamid# What is this empty for command?
for(i in 1:nrow(summary_table))
{
	
}



#rownames(prob_mtx)<-seq(Ntip(tree)+1,Ntip(tree)+Nnode(tree))
rownames(prob_mtx)<-node_number_list

head(prob_mtx)
head(max_prob_mtx)
head(tip_index)


head(node_correspond)
prob_mtx_Rnodes<-prob_mtx
Rnode_names<-c()
for(i in 1:nrow(prob_mtx_Rnodes))
{
	Rnode_names<-c(Rnode_names,node_correspond[which(node_correspond[,2]== rownames(prob_mtx)[i]),1])
}
head(Rnode_names)

setdiff(node_number_list, Rnode_names)

rownames(prob_mtx_Rnodes)<-Rnode_names
head(prob_mtx_Rnodes)

prob_mtx_Rnodes_sort<-prob_mtx_Rnodes[sort(rownames(prob_mtx_Rnodes)),]
head(prob_mtx_Rnodes_sort)

apply(prob_mtx,1,sum)
apply(prob_mtx,2,sum)


prob_mtx_Rnodes["2365",]


#col=c(
#  "#1A5276",
#  "#A9CCE3",
#  "#A1887F",
#  "#F06292",
#  "#C39BD3",
#  "#FFCCBC",
#  "#148F77",
#  "#ABEBC6",
#)
col=c(
  "goldenrod2",
  "cadetblue1",
  "indianred2",
  "mediumspringgreen",
  "chocolate1",
  "dodgerblue",
  "darkred",
#  "purple2",
  "red2"
)
#
#"#6E2C00",
#"#D35400",
#"#F39C12")
#
#F:Africa,S:Australia, P:Palearctic, A:Nearctic,N:Neotropics ,O:Oriental, Z:New-Zealand, T:Antarctica
leg=c("Africa","Australia", "Palearctic", "Nearctic","Neotropics","Oriental", "New-Zealand", "Antarctica")


tip_data_raw<-read.table("DistributionAreas.txt",colClasses="character")
head(tip_data_raw)

tip_data_mtx<-c()
for(i in 1:nrow(tip_data_raw))
{
	tip_data_mtx <- rbind(tip_data_mtx ,unlist(strsplit(tip_data_raw[i,2],split="")))
}
rownames(tip_data_mtx)<-tip_data_raw[,1]

tip_data_mtx_sort<-tip_data_mtx[tree$tip.label,]
head(tip_data_mtx_sort)



### Plot the tree in PDF, but also export the PNG

pdf("plot_REVBAYES_results_piecharts_margProb3.pdf",height=200,width=130)
#par(mar=c(0,0,0,10))

#,type="fan"

plot(tree, show.tip.label = TRUE,cex=0.8)
nodelabels(pie= prob_mtx_Rnodes_sort,piecol= col,cex=0.4) #sum of probability at each node NEED to be 1

legend("topleft",legend= leg,text.col=col,box.lwd = 0,cex=10)

nodelabels(bg="white",cex=0.7) #sum of probability at each node NEED to be 1

adj=0
for(i in 1:ncol(tip_data_mtx_sort))
{
	adj=adj+0.25
	col2=c("white",col[i])
	#tiplabels(bg=col2[biogeoTipRaw2[,i]+1],pch=22,adj=adj,cex=1)
	tiplabels(col=col2[as.numeric(tip_data_mtx_sort[,i])+1],pch=15,adj=adj,cex=1)
}
dev.off()

cmdstr = paste("open ", "plot_REVBAYES_results_piecharts_margProb2test.pdf", sep="")
system(cmdstr) # Plot it





